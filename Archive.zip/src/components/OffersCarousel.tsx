import { useRef, useState } from "react";
import type { Offer } from "../i18n/translations";
import "./OffersCarousel.css";

const DRAG_CLICK_THRESHOLD = 6;

/**
 * A horizontally-scrolling row of vacation offer cards, each pairing a
 * photo with the hotel/flight/price details. Supports native touch/trackpad
 * scrolling, scroll-snap, arrow-button paging, and click-and-drag panning
 * with the mouse (desktop users expect to be able to grab it).
 */
export default function OffersCarousel({ offers }: { offers: Offer[] }) {
  const trackRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);
  const dragState = useRef({
    active: false,
    startX: 0,
    startScroll: 0,
    moved: 0,
  });

  const scrollByCard = (direction: 1 | -1) => {
    const track = trackRef.current;
    if (!track) return;
    const card = track.querySelector<HTMLElement>(".offer-card");
    const step = card ? card.offsetWidth + 20 : track.clientWidth * 0.8;
    track.scrollBy({ left: step * direction, behavior: "smooth" });
  };

  const onPointerDown = (e: React.PointerEvent) => {
    const track = trackRef.current;
    if (!track) return;
    (e.target as Element).setPointerCapture(e.pointerId);
    dragState.current = {
      active: true,
      startX: e.clientX,
      startScroll: track.scrollLeft,
      moved: 0,
    };
    setDragging(true);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const track = trackRef.current;
    const state = dragState.current;
    if (!state.active || !track) return;
    const dx = e.clientX - state.startX;
    state.moved = Math.max(state.moved, Math.abs(dx));
    track.scrollLeft = state.startScroll - dx;
  };

  const endDrag = () => {
    dragState.current.active = false;
    setDragging(false);
  };

  // Prevent a drag-release from also firing as a link click on children.
  const onClickCapture = (e: React.MouseEvent) => {
    if (dragState.current.moved > DRAG_CLICK_THRESHOLD) {
      e.preventDefault();
      e.stopPropagation();
    }
  };

  return (
    <div className="offers-carousel">
      <div
        className={`offers-carousel__track${dragging ? " offers-carousel__track--grabbing" : ""}`}
        ref={trackRef}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onPointerLeave={(e) => {
          if (e.buttons === 0) endDrag();
        }}
        onClickCapture={onClickCapture}
      >
        {offers.map((offer) => (
          <article className="offer-card" key={offer.destination}>
            <div className="offer-card__photo">
              <img
                src={`/offers/${offer.photo}`}
                alt={offer.destination}
                draggable={false}
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).style.display = "none";
                }}
              />
              <span className="offer-card__photo-fallback" aria-hidden="true">
                {offer.emoji}
              </span>
            </div>
            <div className="offer-card__body">
              <h3 className="offer-card__destination">
                <span aria-hidden="true">{offer.emoji}</span> {offer.destination}
              </h3>
              <p className="offer-card__tagline">{offer.tagline}</p>
              <dl className="offer-card__facts">
                <div>
                  <dt>🏨</dt>
                  <dd>{offer.hotel}</dd>
                </div>
                <div>
                  <dt>✈️</dt>
                  <dd>{offer.flight}</dd>
                </div>
                <div>
                  <dt>🌙</dt>
                  <dd>{offer.duration}</dd>
                </div>
                <div>
                  <dt>🍽️</dt>
                  <dd>{offer.meal}</dd>
                </div>
              </dl>
              <ul className="offer-card__prices">
                {offer.prices.map((price) => (
                  <li key={price}>💶 {price}</li>
                ))}
              </ul>
              <p className="offer-card__description">{offer.description}</p>
              {offer.perks && (
                <ul className="offer-card__perks">
                  {offer.perks.map((perk) => (
                    <li key={perk}>{perk}</li>
                  ))}
                </ul>
              )}
            </div>
          </article>
        ))}
      </div>
      <div className="offers-carousel__nav">
        <button
          type="button"
          className="offers-carousel__arrow"
          onClick={() => scrollByCard(-1)}
          aria-label="Previous offer"
        >
          ←
        </button>
        <button
          type="button"
          className="offers-carousel__arrow"
          onClick={() => scrollByCard(1)}
          aria-label="Next offer"
        >
          →
        </button>
      </div>
    </div>
  );
}
